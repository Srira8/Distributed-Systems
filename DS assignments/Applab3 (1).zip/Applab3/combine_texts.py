import sys

def combine_texts(input_files):
    for input_file in input_files:
        with open(input_file, 'r') as infile:
            for line in infile:
                print(line, end='')

if __name__ == "__main__":
    # Check if the correct number of arguments are provided
    if len(sys.argv) < 2:
        print("Usage: python combine_texts.py <input_files>")
        sys.exit(1)
    
    input_files = sys.argv[1:]  # List of input files
    
    combine_texts(input_files)
