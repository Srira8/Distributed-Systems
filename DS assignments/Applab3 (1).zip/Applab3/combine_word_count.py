import sys
from collections import Counter

def combine_word_counts(file_paths):
    combined_counts = Counter()
    for file_path in file_paths:
        with open(file_path, 'r') as file:
            for line in file:
                word, count = line.split()
                combined_counts[word] += int(count)
    return combined_counts

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python combine_word_counts.py <word_count_files>")
        sys.exit(1)
    
    word_count_files = sys.argv[1:]
    combined_counts = combine_word_counts(word_count_files)
    
    # Output top 100 words
    for word, count in combined_counts.most_common(100):
        print(word, count)