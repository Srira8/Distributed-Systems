import sys
from collections import Counter
import string

def count_words(file_path):
    word_count = Counter()
    with open(file_path, 'r') as file:
        for line in file:
            words = line.translate(str.maketrans('', '', string.punctuation)).lower().split()
            word_count.update(words)
    return word_count

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python word_count.py <input_file>")
        sys.exit(1)
    
    input_file = sys.argv[1]
    word_count = count_words(input_file)
    
    for word, count in word_count.most_common():
        print(word, count)