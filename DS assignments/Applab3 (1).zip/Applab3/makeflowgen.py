import os

def generate_makeflow(num_files):
    with open("Makeflow", "w") as makeflow_file:
        # Stage 1: Combine texts into larger .txt files of 10 books each
        for i in range(num_files):
            makeflow_file.write(f"LOCAL file_{i}.txt: input_{i}1.txt input{i}2.txt ... input{i}_10.txt\n")
            makeflow_file.write(f"\tpython3 combine_texts.py books/{i}.txt > file_{i}.txt\n\n")
            
        
        # Stage 2: Analyze each combined file to produce word counts
        for i in range(num_files):
            makeflow_file.write(f"LOCAL word_count_{i}.txt: file_{i}.txt\n")
            makeflow_file.write(f"\tpython3 word_count.py file_{i}.txt > word_count_{i}.txt\n\n")
            
        
        # Stage 3: Combine word counts to produce top 100 list
        makeflow_file.write("LOCAL top_100.txt: ")
        makeflow_file.write(" ".join([f"word_count_{i}.txt" for i in range(num_files)]))
        makeflow_file.write("\n\tpython3 combine_word_counts.py word_count_*.txt > top_100.txt\n\n")
       

if __name__ == "__main__":
    # Count the number of files in the 'books' folder
    num_files = len([name for name in os.listdir('books') if os.path.isfile(os.path.join('books', name))])
    generate_makeflow(num_files)
