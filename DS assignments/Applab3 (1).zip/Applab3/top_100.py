

import os
def produce_top_100(combined_files, output_dir):
    combined_word_counts = {}
    for combined_file in combined_files:
        with open(os.path.join(output_dir, combined_file), 'r') as f:
            text = f.read()
            word_counts = count_words(text)
            for word, count in word_counts.items():
                combined_word_counts[word] = combined_word_counts.get(word, 0) + count
    sorted_word_counts = sorted(combined_word_counts.items(), key=lambda x: x[1], reverse=True)
    top_100_words = sorted_word_counts[:100]
    return top_100_words

# Usage example
top_100_words = produce_top_100("combined_texts/", "output/")
print(top_100_words)
