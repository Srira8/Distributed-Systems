
import pickle
import socket
import sys

def send__receive(host, port, msg):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.connect((host, port))
        sock.sendall(pickle.dumps(msg))
        rsp = sock.recv(1024)
        return pickle.loads(rsp)

def main():
    if len(sys.argv) != 3:
        print("Use: python client.py GCD_HOST GCD_PORT")
        exit(1)

    gcd_host = sys.argv[1]
    gcd_port = int(sys.argv[2])

    # Connecting to GCD and send JOIN message
    gcd_rsp = send__receive(gcd_host, gcd_port, 'JOIN')
    print(f"Group members received from GCD: {gcd_rsp}")

    # PROVIDE HELLO message to each group member
    for index, member in enumerate(gcd_rsp, start=1):
        member__host = member['host']
        member__port = 10700 + index  

        try:
            print(f"Intiating Connection to {member__host}:{member__port}...")
            member_rsp = send__receive(member__host, member__port, 'HELLO')
            print(f"Response from {member__host}:{member__port}: {member_rsp}")
        except (socket.timeout, ConnectionRefusedError) as e:
            print(f"Failed to connect to {member__host}:{member__port}. Error: {e}")

if __name__ == '__main__':
    main()




