#!/usr/bin/python3

import os
import sys
import subprocess


inputFile = sys.argv[1]
output = sys.argv[2]
NumFrames = int(sys.argv[3])
Width = int(sys.argv[4])
Height = int(sys.argv[5])


count = 0;
NumFrames = NumFrames+1

for i in range(0, NumFrames):
    fnum = f"{i:03d}"
    os.system(f"./povray +I{inputFile} +Oframe{fnum}.png +K.{count} Width={Width} Height={Height}")
    print(fnum)
    count=count+1

subprocess.run(f"./ffmpeg -r 10 -i frame%03d.png -r ntsc {output}", shell=True)
subprocess.run("touch worked", shell=True)
