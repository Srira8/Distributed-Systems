import os
import sys
import subprocess
# python3 $(CONDOR) rubiks1080p.pov rubiks1080p.mpg 600 1920 1080

input_file = sys.argv[1]
output = sys.argv[2]
frame_number = int(sys.argv[3])
Width = int(sys.argv[4])
Height = int(sys.argv[5])

if not os.path.exists("povray_out"):
    os.makedirs("povray_out")
if not os.path.exists("povray_err"):
    os.makedirs("povray_err")
if not os.path.exists("povray_log"):
    os.makedirs("povray_log")


count = 0;
frame_number = frame_number+1

for i in range(0, frame_number):
    fnum = f"{i:03d}"
    os.system(f"./povray +I{input_file} +Oframe{fnum}.png +K.{count} Width={Width} Height={Height}")
    content = f"""
Universe = vanilla
Executable = ./povray
Arguments = +I{input_file} +Oframe{frame_number:03d}.png +K.{count} Width={Width} Height={Height}
Output = povray_out/frame{frame_number:03d}.out
Error = povray_err/frame{frame_number:03d}.err
Log = povray_log/frame{frame_number:03d}.log
should_transfer_files = YES
when_to_transfer_output = ON_EXIT
transfer_input_files = {input_file}
Queue
"""
    with open(f"frame{frame_number:03d}.submit", "w") as submit_file:
        submit_file.write(content)
    subprocess.run(["condor_submit", f"frame{frame_number:03d}.submit"])
    print(fnum)
    count=count+1

subprocess.run(["condor_wait"])
os.system(f"./ffmpeg -r 10 -i frame%03d.png -r ntsc {output}")
os.system("rm -rf frame*.png")
